'''piece.py'''

from enum import Enum


class Piece(Enum):
    NoPiece = 0
    Blue = 1
    Red = 2
    BlueCrown = 3
    RedCrown = 4
