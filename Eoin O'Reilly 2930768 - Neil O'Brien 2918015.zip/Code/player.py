'''player.py'''

from enum import Enum


class Player(Enum):
    Player1 = 1
    Player2 = 2
